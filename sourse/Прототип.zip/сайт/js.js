// Ждем, пока весь HTML-документ будет загружен, прежде чем выполнять скрипт.
// Это хорошая практика, чтобы избежать ошибок, если скрипт попытается найти
// элемент, который еще не успел появиться на странице.
document.addEventListener('DOMContentLoaded', function() {

    // --- Управление модальным окном для добавления пользователя ---

    // 1. Находим нужные элементы на странице по их ID и классам.
    const modal = document.getElementById("add-user-modal");
    const openModalBtn = document.querySelector(".btn-primary[onclick='showAddForm()']");
    const closeModalBtn = document.querySelector(".close-btn[onclick='closeAddForm()']");

    // Функция, которая будет открывать модальное окно.
    // Мы ее вызываем по `onclick` на кнопке, но также привяжем через JS.
    function showAddForm() {
        if (modal) { // Проверяем, существует ли модальное окно на странице
            modal.style.display = "block"; // Меняем стиль display с 'none' на 'block', чтобы оно стало видимым
        }
    }

    // Функция, которая будет закрывать модальное окно.
    function closeAddForm() {
        if (modal) {
            modal.style.display = "none"; // Прячем окно, меняя display обратно на 'none'
        }
    }

    // 2. Привязываем события к кнопкам (более современный подход, чем onclick в HTML).
    // Если кнопка "Добавить пользователя" найдена, при клике на нее вызываем функцию showAddForm.
    if (openModalBtn) {
        openModalBtn.onclick = function(event) {
            event.preventDefault(); // Предотвращаем стандартное поведение кнопки (на всякий случай)
            showAddForm();
        };
    }

    // Если кнопка "закрыть" (крестик) найдена, при клике на нее вызываем функцию closeAddForm.
    if (closeModalBtn) {
        closeModalBtn.onclick = function() {
            closeAddForm();
        };
    }

    // 3. Закрытие окна при клике на темный фон за его пределами.
    window.onclick = function(event) {
        // Если пользователь кликнул именно на фон модального окна (а не на его содержимое),
        if (event.target == modal) {
            closeAddForm(); // то закрываем окно.
        }
    }

}); // Конец обработчика DOMContentLoaded