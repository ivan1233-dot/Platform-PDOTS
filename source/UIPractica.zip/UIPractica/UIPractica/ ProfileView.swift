
import SwiftUI

struct ProfileView: View {
    
    let user: User

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            ProfileIconView(fullName: user.fullName)
                .font(.largeTitle)
            
            Divider()
            
            HStack {
                Text("Полное имя:").fontWeight(.bold)
                Text(user.fullName)
            }
            HStack {
                Text("Email:").fontWeight(.bold)
                Text(user.email)
            }
            HStack {
                Text("Дата рождения:").fontWeight(.bold)
                Text(user.birthDate.formatted(date: .long, time: .omitted))
            }
            HStack {
                Text("Роль:").fontWeight(.bold)
                Text(user.role.rawValue)
            }
            
            Spacer()
        }
        .padding(40)
        .font(.title2)
    }
}
