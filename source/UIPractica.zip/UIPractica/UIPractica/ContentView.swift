import SwiftUI

struct ContentView: View {
    @EnvironmentObject var userData: UserData

    var body: some View {
        if let currentUser = userData.currentUser {
            switch currentUser.role {
            case .student:
                StudentDashboardView()
            case .admin:
                AdminDashboardView()
            }
        } else {
            LoginView()
        }
    }
}
