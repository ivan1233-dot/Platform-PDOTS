import SwiftUI

struct SettingsAdminView: View {
    var body: some View {
        Text("Раздел настроек системы")
            .font(.largeTitle)
    }
}
