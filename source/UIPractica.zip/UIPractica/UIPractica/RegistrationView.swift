// RegistrationView.swift
import SwiftUI

struct RegistrationView: View {
    @EnvironmentObject var userData: UserData
    @Binding var isPresented: Bool
    
    @State private var fullName = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var birthDate = Date() // <-- ДОБАВЛЕНО СОСТОЯНИЕ ДЛЯ ДАТЫ
    @State private var showingAlert = false
    @State private var alertMessage = ""

    var body: some View {
        VStack(spacing: 20) {
            Text("Регистрация")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            TextField("Полное имя", text: $fullName)
                .textFieldStyle(.roundedBorder)
            
            TextField("Email", text: $email)
                .textFieldStyle(.roundedBorder)
                .disableAutocorrection(true)
            
            
            DatePicker("Дата рождения:", selection: $birthDate, displayedComponents: .date)
            
            SecureField("Пароль", text: $password)
                .textFieldStyle(.roundedBorder)
            
            SecureField("Повторите пароль", text: $confirmPassword)
                .textFieldStyle(.roundedBorder)
            
            Button("Зарегистрироваться") { handleRegistration() }
                .controlSize(.large)
            
            Button("Уже есть аккаунт? Войти") { isPresented = false }
                .buttonStyle(.link)
        }
        .padding(40)
        .frame(width: 400)
        .alert("Ошибка регистрации", isPresented: $showingAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(alertMessage)
        }
    }
    
    private func handleRegistration() {
        if fullName.isEmpty || email.isEmpty || password.isEmpty {
            alertMessage = "Пожалуйста, заполните все поля."
            showingAlert = true
            return
        }
        if password != confirmPassword {
            alertMessage = "Пароли не совпадают."
            showingAlert = true
            return
        }
    и
        if !userData.registerUser(fullName: fullName, email: email, birthDate: birthDate) {
            alertMessage = "Пользователь с таким email уже существует."
            showingAlert = true
        }
    }
}
