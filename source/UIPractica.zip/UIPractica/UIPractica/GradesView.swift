// GradesView.swift
import SwiftUI

struct GradesView: View {
    var body: some View {
        VStack {
            Image(systemName: "graduationcap.fill")
                .font(.system(size: 60))
                .foregroundColor(.gray)
                .padding()
            Text("Раздел 'Оценки'")
                .font(.largeTitle)
            Text("Здесь будут отображаться оценки студента.")
                .font(.title3)
                .foregroundColor(.secondary)
        }
    }
}
