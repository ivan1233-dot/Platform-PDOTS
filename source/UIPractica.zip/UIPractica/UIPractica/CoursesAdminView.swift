import SwiftUI

struct CoursesAdminView: View {
    var body: some View {
        Text("Раздел управления курсами")
            .font(.largeTitle)
    }
}
