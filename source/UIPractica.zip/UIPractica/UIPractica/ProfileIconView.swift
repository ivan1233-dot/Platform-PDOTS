// ProfileIconView.swift
import SwiftUI

struct ProfileIconView: View {
    let fullName: String
    
    // Функция для получения инициалов
    var initials: String {
        let components = fullName.components(separatedBy: .whitespacesAndNewlines)
        let firstLetters = components.compactMap { $0.first }
        return String(firstLetters.prefix(2)).uppercased()
    }
    
    var body: some View {
        HStack {
            Text(initials)
                .font(.headline)
                .foregroundColor(.white)
                .frame(width: 40, height: 40)
                .background(Color.gray)
                .clipShape(Circle())
            
            Text(fullName)
                .fontWeight(.medium)
        }
    }
}
