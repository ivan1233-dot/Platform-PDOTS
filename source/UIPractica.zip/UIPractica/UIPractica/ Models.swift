// Models.swift
import Foundation

enum Role: String, Codable {
    case student = "Студент"
    case admin = "Преподаватель"
}

struct User: Identifiable, Codable {
    let id: UUID
    var fullName: String
    var email: String
    var role: Role
    var birthDate: Date 
}

struct Course: Identifiable {
    let id = UUID()
    var title: String
    var teacher: String
    var progress: Double
}
