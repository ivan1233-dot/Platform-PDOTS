// PracticaApp.swift
import SwiftUI

@main
struct PracticaApp: App {
    @StateObject var userData = UserData()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(userData)
        }
    }
}
