
import SwiftUI

struct AddUserView: View {
    @EnvironmentObject var userData: UserData

    @Binding var isPresented: Bool
    
    @State private var fullName = ""
    @State private var email = ""
    @State private var birthDate = Date()
    
    @State private var showingAlert = false
    @State private var alertMessage = ""

    var body: some View {
        VStack(spacing: 20) {
            Text("Добавить нового пользователя")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            TextField("Полное имя", text: $fullName)
                .textFieldStyle(.roundedBorder)
            
            TextField("Email", text: $email)
                .textFieldStyle(.roundedBorder)
                .disableAutocorrection(true)
            
            DatePicker("Дата рождения:", selection: $birthDate, displayedComponents: .date)
            
            
            
            HStack {
               
                Button("Отмена") {
                    isPresented = false
                }
                .keyboardShortcut(.cancelAction)
                
                // Кнопка сохранения
                Button("Сохранить") {
                    handleUserCreation()
                }
                .keyboardShortcut(.defaultAction)
            }
            .controlSize(.large)
            .padding(.top)
        }
        .padding(40)
        .frame(width: 450)
        .alert("Ошибка", isPresented: $showingAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(alertMessage)
        }
    }
    
    private func handleUserCreation() {
        if fullName.isEmpty || email.isEmpty {
            alertMessage = "Пожалуйста, заполните имя и email."
            showingAlert = true
            return
        }
        

        if userData.registerUser(fullName: fullName, email: email, birthDate: birthDate) {
            isPresented = false
        } else {
            alertMessage = "Пользователь с таким email уже существует."
            showingAlert = true
        }
    }
}
