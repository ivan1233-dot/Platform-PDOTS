// UserData.swift
import Foundation
import Combine
import SwiftUI

class UserData: ObservableObject {
    @Published var users: [User]
    @Published var courses: [Course]
    @Published var currentUser: User? = nil

    init() {
  
        self.users = [
            User(id: UUID(), fullName: "Вяльцев Максим", email: "m.vyalcev@list.ru", role: .student, birthDate: Date()),
            User(id: UUID(), fullName: "Герасимов Павел", email: "gpasa244@gmail.com", role: .student, birthDate: Date()),
            User(id: UUID(), fullName: "Глушков Александр", email: "alex69@gmail.com", role: .admin, birthDate: Date())
        ]
        self.courses = [
            Course(title: "Основы C++", teacher: "О.И. Назарова", progress: 0.05),
            Course(title: "Архитектура ПО", teacher: "О.И. Назарова", progress: 0.20),
            Course(title: "Базы данных", teacher: "О.И. Назарова", progress: 0.05)
        ]
    }

    func login(email: String, role: Role) -> Bool {
        if let user = users.first(where: { $0.email.lowercased() == email.lowercased() && $0.role == role }) {
            currentUser = user
            return true
        }
        return false
    }

    func logout() {
        currentUser = nil
    }
    
    
    func registerUser(fullName: String, email: String, birthDate: Date) -> Bool {
        if users.contains(where: { $0.email.lowercased() == email.lowercased() }) {
            return false
        }
       
        let newUser = User(id: UUID(), fullName: fullName, email: email, role: .student, birthDate: birthDate)
        users.append(newUser)
        currentUser = newUser
        return true
    }

    func removeUser(at offsets: IndexSet) {
        users.remove(atOffsets: offsets)
    }
}
