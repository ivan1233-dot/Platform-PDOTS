// LoginView.swift
import SwiftUI

struct LoginView: View {
    @EnvironmentObject var userData: UserData
    
    @State private var email = ""
    @State private var password = ""
    @State private var showingAlert = false
    @State private var showingRegistration = false

    var body: some View {
        VStack(spacing: 20) {
            Text("Вход в систему")
                .font(.largeTitle).bold()
            
            Text("Выберите роль для входа")
                .foregroundColor(.secondary)
            
            TextField("Email", text: $email)
                .textFieldStyle(.roundedBorder)
                // Строка .textInputAutocapitalization(.never) УДАЛЕНА
                .disableAutocorrection(true)
            
            SecureField("Пароль", text: $password)
                .textFieldStyle(.roundedBorder)
            
            Button("Войти как студент") {
                if !userData.login(email: email, role: .student) { showingAlert = true }
            }
            .controlSize(.large)
            // Строка .keyboardShortcut(.defaultAction) УДАЛЕНА

            Button("Войти как администратор") {
                if !userData.login(email: email, role: .admin) { showingAlert = true }
            }
            .controlSize(.large)
            .tint(.green)
            
            Button("Зарегистрироваться") { showingRegistration = true }
                .buttonStyle(.link)
                .padding(.top)
        }
        .padding(40)
        .frame(width: 400)
        .alert("Ошибка входа", isPresented: $showingAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Неверный email или роль пользователя.")
        }
        .sheet(isPresented: $showingRegistration) {
            RegistrationView(isPresented: $showingRegistration)
        }
    }
}
