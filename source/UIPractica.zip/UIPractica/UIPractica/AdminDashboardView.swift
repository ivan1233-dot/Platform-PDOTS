
import SwiftUI

struct UsersTableView: View {
    @EnvironmentObject var userData: UserData
    
    var body: some View {
        Table(userData.users) {
            TableColumn("ФИО", value: \.fullName)
            TableColumn("Email", value: \.email)
            TableColumn("Роль") { user in
                Text(user.role.rawValue)
            }
        }
    }
}

struct AdminDashboardView: View {
    @EnvironmentObject var userData: UserData
    @State private var showingAddUser = false
    @State private var selection: String? = "Пользователи"

    var body: some View {
        NavigationSplitView {
        
            List(selection: $selection) {
                Label("Пользователи", systemImage: "person.3")
                    .tag("Пользователи")
                Label("Курсы", systemImage: "books.vertical")
                    .tag("Курсы")
                Label("Настройки", systemImage: "gear")
                    .tag("Настройки")
            }
            .listStyle(.sidebar)
            .frame(minWidth: 180)
            
            Spacer()
            
            Button(action: userData.logout) {
                Label("Выйти", systemImage: "arrow.backward.square")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding()
            .buttonStyle(.plain)
            
        } detail: {
            VStack(alignment: .leading) {
                
                HStack {
                    Text(selection ?? "Пользователи")
                        .font(.largeTitle).bold()
                    Spacer()
                    
                    if selection == "Пользователи" {
                        Button("+ Добавить пользователя") {
                            showingAddUser = true
                        }
                    }
                }
                .padding([.horizontal, .top])
                
                switch selection {
                case "Пользователи":
                    UsersTableView()
                        .padding(.horizontal)
                case "Курсы":
                    CoursesAdminView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                case "Настройки":
                    SettingsAdminView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                default:
                    Text("Выберите раздел")
                }
            }
            .sheet(isPresented: $showingAddUser) {
                AddUserView(isPresented: $showingAddUser)
            }
        }
        .frame(minWidth: 800, minHeight: 500)
    }
}


struct AddUserView: View {
    @Binding var isPresented: Bool 
    
    
    @State private var fullName: String = ""
    @State private var email: String = ""
    @State private var birthDate = Date()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Добавить нового пользователя")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            TextField("Полное имя", text: $fullName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            
            TextField("Email", text: $email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            
            DatePicker("Дата рождения:", selection: $birthDate, displayedComponents: .date)
            
            HStack(spacing: 20) {
                Button("Отмена") {
                    isPresented = false // Закрыть окно
                }
                
                Button("Сохранить") {
                    // Здесь будет логика сохранения пользователя
                    print("Пользователь \(fullName) сохранен.")
                    isPresented = false // Закрыть окно
                }
            }
        }
        .padding(40)
        .frame(minWidth: 400)
    }
}
