
import SwiftUI

struct CoursesView: View {
    @EnvironmentObject var userData: UserData
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 300))], spacing: 20) {
                ForEach(userData.courses) { course in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(course.title).font(.headline)
                        Text("Преподаватель: \(course.teacher)").font(.subheadline).foregroundStyle(.secondary)
                        ProgressView(value: course.progress)
                        Text("Прогресс: \(Int(course.progress * 100))%").font(.caption).foregroundStyle(.blue)
                    }
                    .padding()
                    .background(Color(nsColor: .windowBackgroundColor))
                    .cornerRadius(10)
                    .shadow(radius: 2)
                }
            }
            .padding()
        }
    }
}


struct StudentDashboardView: View {
    @EnvironmentObject var userData: UserData
    @State private var selection: String? = "Мои курсы"

    var body: some View {
        NavigationSplitView {
          
            List(selection: $selection) {
                Label("Мои курсы", systemImage: "books.vertical")
                    .tag("Мои курсы")
                Label("Оценки", systemImage: "graduationcap")
                    .tag("Оценки")
                Label("Профиль", systemImage: "person.crop.circle")
                    .tag("Профиль")
            }
            .listStyle(.sidebar)
            .frame(minWidth: 180)
            
            Spacer()
            
            Button(action: userData.logout) {
                Label("Выйти", systemImage: "arrow.backward.square")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding()
            .buttonStyle(.plain)

        } detail: {
      
            VStack {
                
                HStack {
        
                    Text(selection ?? "Мои курсы")
                        .font(.largeTitle).bold()
                    Spacer()
                    if let currentUser = userData.currentUser {
                        ProfileIconView(fullName: currentUser.fullName)
                    }
                }
                .padding([.horizontal, .top])
                
                switch selection {
                case "Мои курсы":
                    CoursesView()
                case "Оценки":
                    GradesView()
                case "Профиль":
                    if let user = userData.currentUser {
                        ProfileView(user: user)
                    } else {
                        Text("Ошибка: не удалось загрузить данные пользователя.")
                    }
                default:
                    Text("Выберите раздел из меню слева")
                }
            }
        }
        .frame(minWidth: 800, minHeight: 500)
    }
}
